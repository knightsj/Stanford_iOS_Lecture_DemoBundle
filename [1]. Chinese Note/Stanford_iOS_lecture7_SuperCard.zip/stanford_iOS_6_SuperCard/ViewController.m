//
//  ViewController.m
//  stanford_iOS_6_SuperCard
//
//  Created by SHIJIE on 16/7/4.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"
#import "PlayingCardView.h"

@interface ViewController ()

@property (nonatomic, strong) IBOutlet PlayingCardView *playCardView;

@end

@implementation ViewController

/**
 *  滑动手势翻转牌
 *
 *  @param sender 滑动手势
 */
- (IBAction)swipe:(id)sender {
   
    //翻转牌面
    self.playCardView.faceUp  = !self.playCardView.faceUp;
    
}

- (void)viewDidLoad {
    
    [super viewDidLoad];

    self.playCardView.suit = @"♠︎";
    self.playCardView.rank = 13;
    //添加捏合手势
    [self.playCardView addGestureRecognizer:[[UIPinchGestureRecognizer alloc] initWithTarget:self.playCardView
                                                                                      action:@selector(pinch:)]];
}

@end
