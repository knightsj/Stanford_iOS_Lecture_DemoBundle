//
//  AppDelegate.h
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

