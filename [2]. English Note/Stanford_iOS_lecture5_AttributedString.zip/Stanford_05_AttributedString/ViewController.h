//
//  ViewController.h
//  Stanford_05_AttributedString
//
//  Created by SHIJIE on 16/6/5.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

