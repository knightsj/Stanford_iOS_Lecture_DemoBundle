//
//  FlickrAPIKey.h
//
//  Created for Stanford CS193p Fall 2013.
//  Copyright 2013 Stanford University. All rights reserved.
//
//  Get your own key!
//  No Flickr fetches will work without the API Key!
//

#define FlickrAPIKey @"fb86f33411b63ec4fcc896dd54d98717"
//在这里申请key : "http://www.flickr.com/services/api/misc.api_keys.html"