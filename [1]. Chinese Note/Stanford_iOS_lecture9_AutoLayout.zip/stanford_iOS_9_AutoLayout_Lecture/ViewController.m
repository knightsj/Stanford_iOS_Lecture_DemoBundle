//
//  ViewController.m
//  stanford_iOS_9_AutoLayout_Lecture
//
//  Created by Shijie Sun on 16/7/7.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
