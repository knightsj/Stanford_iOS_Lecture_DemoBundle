//
//  CardGameViewController.m
//  CardMatchingGame
//
//  Created by SHIJIE on 16/7/2.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "CardGameViewController.h"
#import "PlayingCardDeck.h"

@interface CardGameViewController ()

@end

@implementation CardGameViewController


//只需要实现
- (Deck *)createDeck
{
    return [[PlayingCardDeck alloc] init];
}

@end
