//
//  Photo+CoreDataProperties.h
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Photo.h"

NS_ASSUME_NONNULL_BEGIN

@interface Photo (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *title;
@property (nullable, nonatomic, retain) NSString *subtittle;
@property (nullable, nonatomic, retain) NSString *imageURL;
@property (nullable, nonatomic, retain) NSString *unique;
@property (nullable, nonatomic, retain) Photographer *whoTook;

/**
 *  根据flickr字典创建照片，放在数据库里。如果已经存在，就找到它
 */
+ (Photo *)photoWithFlickrInfo:(NSDictionary *)photoDictionary inManagedObjectContext: (NSManagedObjectContext *)context;

/**
 *  将多个图片数据放入数据库里
 */
+ (void)loadPhotosFromFlickrArray: (NSArray *)photos intoManagedObjectContext:(NSManagedObjectContext *)context;


@end




NS_ASSUME_NONNULL_END

