//
//  ViewController.m
//  stanford_lecture2_card
//
//  Created by SHIJIE on 16/6/19.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"
#import "PlayingCardDeck.h"
#import "CardMatchingGame.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *flipsLabel;
@property (nonatomic) int flipCount;
@property (nonatomic, strong) Deck *deck;
@property (nonatomic, retain) CardMatchingGame *game;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;

@end

@implementation ViewController

- (CardMatchingGame *)game
{
    if (!_game) {
        _game = [[CardMatchingGame alloc] initWithCardCount:0 usingDeck:[self createDeck]];
    }
    
    return _game;
}

- (Deck *)deck
{
    if (!_deck) {
        _deck = [self createDeck];
    }
    
    return _deck;
}

- (Deck *)createDeck
{
    return [[PlayingCardDeck alloc] init];
}

- (void)setFlipCount:(int)flipCount
{
    _flipCount = flipCount;
    
    //after setting the filp count, set the number in the Label
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d", self.flipCount];
}


- (IBAction)touchCardButton:(UIButton *)sender {
    
    //if we can get title, we know that the card is face up
    if ([sender.currentTitle length]) {
        
        
        [sender setBackgroundImage:[UIImage imageNamed:@"cardBack"] forState:UIControlStateNormal];
        
        [sender setTitle:@"" forState:UIControlStateNormal];
        
        //add the flipCount
        self.flipCount++;
        
        //update the number in the label
        [self updateFlipsLabel];
        
    }else{
        
        Card *card = [self.deck drawRandomCard];
        
        if (card) {
           
            [sender setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
            
            [sender setBackgroundColor:[UIColor whiteColor]];
            
            [sender setTitle:card.contents forState:UIControlStateNormal];
            
            self.flipCount++;
            
            [self updateFlipsLabel];
        }
        
    }
    
    
}

/**
 *  private method to update the UI of the flipsLabel
 */
- (void)updateFlipsLabel
{
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d", self.flipCount];
}

@end
