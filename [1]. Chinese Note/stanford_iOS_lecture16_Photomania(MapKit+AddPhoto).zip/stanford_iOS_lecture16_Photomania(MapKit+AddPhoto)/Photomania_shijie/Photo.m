//
//  Photo.m
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "Photo.h"
#import "Photographer.h"

@implementation Photo

// Insert code here to add functionality to your managed object subclass

@end
