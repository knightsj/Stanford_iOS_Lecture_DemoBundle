//
//  PlayingCardDeck.h
//  stanford_lecture_2
//
//  Created by SHIJIE on 16/6/19.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Deck.h"

@interface PlayingCardDeck : Deck

@end
