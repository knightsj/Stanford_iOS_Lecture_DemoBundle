//
//  ViewController.m
//  CardMatchingGame
//
//  Created by SHIJIE on 16/6/26.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"
#import "CardMatchingGame.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *scoreLabel;
@property (nonatomic) int flipCount;
@property (nonatomic, strong) Deck *deck;
@property (nonatomic, retain) CardMatchingGame *game;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;
@end

@implementation ViewController


- (CardMatchingGame *)game
{
    if (!_game) {
        _game = [[CardMatchingGame alloc] initWithCardCount:[self.cardButtons count] usingDeck:[self createDeck]];
    }
    
    return _game;
}

/**
 *  Abstract Method
 *
 *  @return 纸牌
 */
- (Deck *)createDeck
{
    //将该类抽象化，不能被实例化使用，创建一个它的具体子类
    return nil;
}

/**
 *  接收用户的点击事件
 *
 *  @param sender 点击的按钮对象
 */
- (IBAction)touchCardButton:(UIButton *)sender {
    
    //1. 找到界面中所点击的按钮index
    NSInteger cardIndex = [self.cardButtons indexOfObject:sender];
    
    //2. 找到模型中相同index的纸牌数据，并判断是否匹配，计算分数
    [self.game chooseCardAtIndex: cardIndex];
    
    //3. 更新UI
    [self updateUI];
    
}

/**
 *  更新界面
 */
- (void)updateUI
{
    //1. 更新view上所有牌面
    for (UIButton *cardButton in self.cardButtons) {
        
        //1.1 找到界面中的一张纸牌(按照枚举的顺序)
        NSInteger cardIndex = [self.cardButtons indexOfObject:cardButton];
        
        //1.2 找到模型中对应的纸牌数据
        Card *card  = [self.game cardAtIndex:cardIndex];
        
        //1.3 根据数据更新纸牌的UI和可点击性
        [cardButton setTitle:[self titleForCard:card] forState:UIControlStateNormal];
        [cardButton setBackgroundImage: [self backgroundImageForCard:card] forState:UIControlStateNormal];
         cardButton.enabled = !card.isMatched;
        
        
    }
    
    //2. 更新分数
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %ld", (long)self.game.score];
}

- (NSString *)titleForCard: (Card *)card
{
    return card.isChosen? card.contents:@"";
}

- (UIImage *)backgroundImageForCard: (Card *)card
{
    //默认是png，如果是jpg需要加上.jpg的后缀
    return [UIImage imageNamed:card.isChosen? @"cardFront.jpg":@"CardBack.png"];
}

@end
