//
//  ImageViewController.h
//  stanford_iOS_10_Imaginarium
//
//  Created by Shijie Sun on 16/7/8.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController

@property (nonatomic, retain) NSURL *imageURL;

@end
