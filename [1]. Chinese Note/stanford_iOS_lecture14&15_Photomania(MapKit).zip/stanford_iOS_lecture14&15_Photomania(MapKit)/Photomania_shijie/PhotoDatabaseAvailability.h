//
//  PhotoDatabaseAvailability.h
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#ifndef PhotoDatabaseAvailability_h
#define PhotoDatabaseAvailability_h

#define PhotoDatabaseAvailabilityNotification @"PhotoDatabaseAvailabilityNotification"
#define PhotoDatabaseAvailabilityContext @"Context"

#endif /* PhotoDatabaseAvailability_h */
