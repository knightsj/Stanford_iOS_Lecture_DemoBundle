//
//  Card.h
//  BasicCard
//
//  Created by SHIJIE on 16/6/23.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Card : NSObject

@property (nonatomic, strong) NSString *contents;

@property (nonatomic, assign,getter=isChosen) BOOL chosen;
@property (nonatomic, assign,getter=isMatched) BOOL matched;

- (int)match : (NSArray *)otherCards;

@end
