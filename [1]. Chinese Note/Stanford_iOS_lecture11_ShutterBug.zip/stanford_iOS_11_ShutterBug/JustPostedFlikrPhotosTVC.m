//
//  JustPostedFlikrPhotosTVC.m
//  stanford_iOS_11_ShutterBug
//
//  Created by Shijie Sun on 16/7/11.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import "JustPostedFlikrPhotosTVC.h"
#import "FlickrFetcher.h"

@interface JustPostedFlikrPhotosTVC ()

@end

@implementation JustPostedFlikrPhotosTVC

- (void)viewDidLoad {

    [super viewDidLoad];
    [self fetchPhotos];
    
    //需要在FlickrAPIKey文件里写入key
    //在这里申请key : "http://www.flickr.com/services/api/misc.api_keys.html"

}

- (void)fetchPhotos
{
    self.photos = nil;
   
    //从flickr拿来照片
    NSURL *url = [FlickrFetcher URLforRecentGeoreferencedPhotos];
    
    dispatch_queue_t fetchQ = dispatch_queue_create("flickr fetcher", NULL);
    dispatch_async(fetchQ, ^{
        
        NSData *jsonResults = [NSData dataWithContentsOfURL:url];
        NSDictionary *propertyListResults = [NSJSONSerialization JSONObjectWithData:jsonResults options:0 error:NULL];
        NSArray *photos = [propertyListResults valueForKeyPath:FLICKR_RESULTS_PHOTOS];
    
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.photos = photos;
        });
    
    });
    
}



@end
