//
//  FlickrPhotosTVC.h
//  stanford_iOS_11_ShutterBug
//
//  Created by Shijie Sun on 16/7/11.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlickrPhotosTVC : UITableViewController

@property (nonatomic, retain) NSArray *photos;

@end
