//
//  PlayingCard.h
//  stanford_lecture_2
//
//  Created by SHIJIE on 16/6/19.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Card.h"
@interface PlayingCard :Card
@property (nonatomic, strong) NSString *suit;
@property (nonatomic, assign) NSInteger rank;

+ (NSArray *)rankStrings;
+ (NSArray *)ValidSuits;
+ (NSInteger *)maxRank;

@end
