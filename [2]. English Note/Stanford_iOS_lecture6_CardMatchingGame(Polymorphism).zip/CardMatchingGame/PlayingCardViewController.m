//
//  PlayingCardViewController.m
//  CardMatchingGame
//
//  Created by SHIJIE on 16/7/2.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "PlayingCardViewController.h"
#import "PlayingCardDeck.h"

@interface PlayingCardViewController ()

@end

@implementation PlayingCardViewController

- (Deck *)createDeck
{
    return [[PlayingCardDeck alloc] init];
}

@end
