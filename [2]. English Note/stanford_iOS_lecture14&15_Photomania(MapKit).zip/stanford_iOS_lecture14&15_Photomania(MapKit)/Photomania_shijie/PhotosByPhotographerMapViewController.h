//
//  PhotosByPhotographerMapViewController.h
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/23.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Photographer.h"

@interface PhotosByPhotographerMapViewController : UIViewController
@property (nonatomic, strong) Photographer *photographer;

@end
