//
//  Photographer.h
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Photo;

NS_ASSUME_NONNULL_BEGIN

@interface Photographer : NSManagedObject

+ (Photographer *)photoGrapherWithName: (NSString *)name
                inManagedObjectContext: (NSManagedObjectContext *)context;



@end

NS_ASSUME_NONNULL_END

#import "Photographer+CoreDataProperties.h"
