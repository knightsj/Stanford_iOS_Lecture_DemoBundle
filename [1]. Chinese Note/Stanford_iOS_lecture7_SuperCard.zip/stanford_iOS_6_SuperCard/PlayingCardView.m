//
//  PlayingCardView.m
//  stanford_iOS_6_SuperCard
//
//  Created by SHIJIE on 16/7/4.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "PlayingCardView.h"
#define DEFAULT_FACE_CARD_SCALE_FACTOR 0.90


@interface PlayingCardView()

@property (nonatomic, assign) CGFloat faceCardScaleFactor;

@end

@implementation PlayingCardView

@synthesize faceCardScaleFactor  = _faceCardScaleFactor;

- (CGFloat)faceCardScaleFactor
{
    if (!_faceCardScaleFactor)  _faceCardScaleFactor = DEFAULT_FACE_CARD_SCALE_FACTOR;
    return _faceCardScaleFactor;
}

- (void)setFaceCardScaleFactor:(CGFloat)faceCardScaleFactor
{
    _faceCardScaleFactor = faceCardScaleFactor;
    [self setNeedsDisplay];//调用drawRect
}

- (void)setSuit:(NSString *)suit
{
    _suit = suit;
    [self setNeedsDisplay];
}

- (void)setRank:(NSUInteger)rank
{
    _rank = rank;
    [self setNeedsDisplay];
}

- (void)setFaceUp:(BOOL)faceUp
{
    _faceUp = faceUp;
    [self setNeedsDisplay];
}

- (void)awakeFromNib
{
    //从故事版中创建视图
    [self setup];
}

- (void)setup
{
    self.backgroundColor = nil;
    self.opaque = NO;
    //如果bounds变化，就调用drawRect:方法
    self.contentMode = UIViewContentModeRedraw;
}



#define CORNER_FONT_STANDAND_HEIGHT 180.0
#define CORNER_RADIUS 10.0

- (CGFloat)cornerScaleFactor {return  self.bounds.size.height / CORNER_FONT_STANDAND_HEIGHT;}
- (CGFloat)cornerRadius {return CORNER_RADIUS * [self cornerScaleFactor];}
- (CGFloat)cornerOffset {return [self cornerRadius] / 3.0f;}


- (void)drawRect:(CGRect)rect {

    
    //初始化一个圆角矩形
    UIBezierPath *roundRect = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:[self cornerRadius]];
    
    //裁剪，保证不会绘制四角
    [roundRect addClip];
    
    //填充白色
    [[UIColor whiteColor] setFill];
     UIRectFill(self.bounds);
    
    //轮廓
    [[UIColor blackColor] setStroke];
    [roundRect stroke];
    
    if (self.faceUp) {
        
        //1. 纸牌正面
        //1.1 纸牌正面中间的图
        UIImage *faceImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@%@",[self rankAsString],self.suit]];
        
        if (faceImage) {
            
            CGRect imageRect = CGRectInset(self.bounds, self.bounds.size.width * (1.0 - self.faceCardScaleFactor) + 20, self.bounds.size.height * ( 1.0 - self.faceCardScaleFactor  ) + 20);
            [faceImage drawInRect:imageRect];
        }
        
        //1.2 纸牌正面四个角
        [self drawCorners];
        
    }else{
        
        //2. 纸牌背面
        [[UIImage imageNamed:@"cardBack"] drawInRect:self.bounds];
    }
    
}


/**
 *  绘制纸牌正面的边角的花色和数字
 */
- (void)drawCorners
{
    
    NSMutableParagraphStyle *paragraphStype = [[NSMutableParagraphStyle alloc] init];
    paragraphStype.alignment = NSTextAlignmentCenter;
    UIFont *cornerFont = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    cornerFont = [cornerFont fontWithSize:cornerFont.pointSize * [self cornerScaleFactor]];
    
    //角落文字
    NSAttributedString *cornerText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@\n%@", [self rankAsString], self.suit] attributes:@{NSFontAttributeName:cornerFont,NSParagraphStyleAttributeName:paragraphStype}];
    
    //左上角
    CGRect textBounds;
    textBounds.origin = CGPointMake([self cornerOffset], [self cornerOffset]);
    textBounds.size = [cornerText size];
    [cornerText drawInRect:textBounds];
    
    //右下角:需要翻转
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, self.bounds.size.width, self.bounds.size.height);
    CGContextRotateCTM(context, M_PI);
    [cornerText drawInRect:textBounds];
    
}

- (NSString *)rankAsString
{
    return @[@"?",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"J",@"Q",@"K"][self.rank];
}

/**
 *  两个手指伸缩图片
 *
 *  @param gesture 捏合手势
 */
- (void)pinch:(UIPinchGestureRecognizer *)gesture
{
    if (gesture.state == UIGestureRecognizerStateChanged || gesture.state == UIGestureRecognizerStateEnded) {
        self.faceCardScaleFactor *= gesture.scale;
        gesture.scale = 1.0;
    }
}


@end
