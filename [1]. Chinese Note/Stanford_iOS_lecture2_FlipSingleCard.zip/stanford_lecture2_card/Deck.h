//
//  Deck.h
//  BasicCard
//
//  Created by SHIJIE on 16/6/23.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Card.h"

@interface Deck : NSObject

- (void)addCard: (Card *)card atTop:(BOOL)atTop;
- (void)addCard: (Card *)card;
- (Card *)drawRandomCard;

@end
