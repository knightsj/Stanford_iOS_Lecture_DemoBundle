//
//  PhotographerCDTVC.m
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//
//Photomania_shijie
#import "PhotographerCDTVC.h"
#import "Photographer+CoreDataProperties.h"
#import "PhotoDatabaseAvailability.h"

@implementation PhotographerCDTVC

- (void)awakeFromNib
{
    [[NSNotificationCenter defaultCenter] addObserverForName:PhotoDatabaseAvailabilityNotification
                                                      object:nil
                                                       queue:nil
                                                  usingBlock:^(NSNotification *note) {
                                                      self.managedObjectContext = note.userInfo[PhotoDatabaseAvailabilityContext];
                                                  }];
}

- (void)setManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{

    _managedObjectContext = managedObjectContext;
    
    NSFetchRequest *requet = [NSFetchRequest fetchRequestWithEntityName:@"Photographer"];
    requet.predicate = nil;//all data,not pickable
    requet.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES selector:@selector(localizedStandardCompare:)]];

    self.fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:requet managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:nil];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Photographer cell"];
    
    Photographer *photographer = [self.fetchedResultsController objectAtIndexPath:indexPath];
    cell.textLabel.text = photographer.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%lu photos", [photographer.photos count]];
    
    return cell;
    
}
@end
