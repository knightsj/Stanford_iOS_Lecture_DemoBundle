//
//  ViewController.m
//  stanford_iOS_6_SuperCard
//
//  Created by SHIJIE on 16/7/4.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"
#import "PlayingCardView.h"

@interface ViewController ()

@property (nonatomic, strong) IBOutlet PlayingCardView *playCardView;

@end

@implementation ViewController

/**
 *  swipe action
 *
 *  @param sender swipe gesture
 */
- (IBAction)swipe:(id)sender {
   
    //flip the card
    self.playCardView.faceUp  = !self.playCardView.faceUp;
    
}

- (void)viewDidLoad {
    
    [super viewDidLoad];

    self.playCardView.suit = @"♠︎";
    self.playCardView.rank = 13;
    //add pinch gesture
    [self.playCardView addGestureRecognizer:[[UIPinchGestureRecognizer alloc] initWithTarget:self.playCardView
                                                                                      action:@selector(pinch:)]];
}

@end
