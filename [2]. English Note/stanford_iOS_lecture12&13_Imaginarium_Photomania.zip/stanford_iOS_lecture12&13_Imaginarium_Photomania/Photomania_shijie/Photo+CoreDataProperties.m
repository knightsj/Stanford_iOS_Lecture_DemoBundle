//
//  Photo+CoreDataProperties.m
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/17.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Photo+CoreDataProperties.h"
#import "FlickrFetcher.h"
#import "Photographer+CoreDataProperties.h"

@implementation Photo (CoreDataProperties)

@dynamic title;
@dynamic subtittle;
@dynamic imageURL;
@dynamic unique;
@dynamic whoTook;

/**
 *  get photo from core data
 */
+ (Photo *)photoWithFlickrInfo:(NSDictionary *)photoDictionary inManagedObjectContext: (NSManagedObjectContext *)context{
    
    Photo *photo = nil;
    NSString *unique = photoDictionary[FLICKR_PHOTO_ID];
    
    //查看数据库是否有照片
    NSFetchRequest *request = [[NSFetchRequest alloc] initWithEntityName:@"Photo"];
    request.predicate = [NSPredicate predicateWithFormat:@"unique = %@",unique];
    
    NSError *error;
    NSArray *matches = [context executeFetchRequest:request error:&error];
    
    if (!matches || error || [matches count]>1) {
        //handle error
    
    }else if ([matches count]){
        
        photo = [matches firstObject];
        
    
    }else{
       
        //creat one
        photo = [NSEntityDescription insertNewObjectForEntityForName:@"Photo" inManagedObjectContext:context];
        photo.unique = unique;
        photo.title = [photoDictionary valueForKeyPath:FLICKR_PHOTO_TITLE];
        photo.subtittle = [photoDictionary valueForKeyPath:FLICKR_PHOTO_DESCRIPTION];
        photo.imageURL = [[FlickrFetcher URLforPhoto:photoDictionary format:FlickrPhotoFormatLarge] absoluteString];
        NSString *photographerName = [photoDictionary valueForKeyPath:FLICKR_PHOTO_OWNER];
        photo.whoTook = [Photographer photoGrapherWithName:photographerName inManagedObjectContext:context];
        
    }
    return nil;
}

/**
 *  将多个图片数据放入数据库里
 */
+ (void)loadPhotosFromFlickrArray: (NSArray *)photos intoManagedObjectContext:(NSManagedObjectContext *)context{
    
    for (NSDictionary *photo in photos) {
        [self photoWithFlickrInfo:photo inManagedObjectContext:context];
    }
}

@end
