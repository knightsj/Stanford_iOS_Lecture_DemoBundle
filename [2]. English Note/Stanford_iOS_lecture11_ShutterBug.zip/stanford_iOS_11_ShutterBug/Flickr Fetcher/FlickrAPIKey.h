//
//  FlickrAPIKey.h
//
//  Created for Stanford CS193p Fall 2013.
//  Copyright 2013 Stanford University. All rights reserved.
//
//  Get your own key!
//  No Flickr fetches will work without the API Key!
//

#define FlickrAPIKey @""
//please apply for your own key at : "http://www.flickr.com/services/api/misc.api_keys.html"