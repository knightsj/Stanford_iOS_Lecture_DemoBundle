//
//  Photo+Annotation.h
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/23.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "Photo.h"
#import <MapKit/MapKit.h>

@interface Photo (Annotation) <MKAnnotation>

@end
