//
//  JustPostedFlikrPhotosTVC.m
//  stanford_iOS_11_ShutterBug
//
//  Created by Shijie Sun on 16/7/11.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import "JustPostedFlikrPhotosTVC.h"
#import "FlickrFetcher.h"

@interface JustPostedFlikrPhotosTVC ()

@end

@implementation JustPostedFlikrPhotosTVC

- (void)viewDidLoad {

    [super viewDidLoad];
    
    //In FlickrAPIKey.h,you should write your own key
    //apply site : "http://www.flickr.com/services/api/misc.api_keys.html"
    
    [self fetchPhotos];

}

- (void)fetchPhotos
{
    self.photos = nil;
   
    //get data from Flickr
    NSURL *url = [FlickrFetcher URLforRecentGeoreferencedPhotos];
    
    dispatch_queue_t fetchQ = dispatch_queue_create("flickr fetcher", NULL);
    dispatch_async(fetchQ, ^{
        
        NSData *jsonResults = [NSData dataWithContentsOfURL:url];
        NSDictionary *propertyListResults = [NSJSONSerialization JSONObjectWithData:jsonResults options:0 error:NULL];
        NSArray *photos = [propertyListResults valueForKeyPath:FLICKR_RESULTS_PHOTOS];
    
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.photos = photos;
        });
    
    });
    
}



@end
