//
//  AppDelegate.h
//  stanford_lecture2_card
//
//  Created by SHIJIE on 16/6/19.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

