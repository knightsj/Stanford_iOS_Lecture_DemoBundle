//
//  TextAnylizeViewController.m
//  Stanford_05_AttributedString
//
//  Created by SHIJIE on 16/7/2.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "TextAnylizeViewController.h"

@interface TextAnylizeViewController ()
@property (strong, nonatomic) IBOutlet UILabel *colorfulCharactersLabel;
@property (strong, nonatomic) IBOutlet UILabel *outlinedCharactersLabel;

@end

@implementation TextAnylizeViewController

- (void)setTextToAnalyze:(NSAttributedString *)textToAnalyze
{
    _textToAnalyze = textToAnalyze;
    if(self.view.window) [self updateUI];
    
}

- (void)updateUI
{
     self.colorfulCharactersLabel.text = [NSString stringWithFormat:@"%lu colorful characters",(unsigned long)[[self charactersWithAttribute:NSForegroundColorAttributeName] length]];
    
     self.outlinedCharactersLabel.text = [NSString stringWithFormat:@"%lu outlined characters",(unsigned long)[[self charactersWithAttribute:NSStrokeWidthAttributeName] length]];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self updateUI];
}


- (NSAttributedString *)charactersWithAttribute: (NSString *)attributedName
{
    NSMutableAttributedString *characters = [[NSMutableAttributedString alloc] init];
    
    NSUInteger index = 0;
    
    while (index < [self.textToAnalyze length]) {
        NSRange range;
        id value = [self.textToAnalyze attribute:attributedName atIndex:index effectiveRange:&range];
        if (value) {
            [characters appendAttributedString:[self.textToAnalyze attributedSubstringFromRange:range]];
            index = range.location + range.length;
        
        }else{
            index ++;
        }
    }
    
    return characters;
}


@end
