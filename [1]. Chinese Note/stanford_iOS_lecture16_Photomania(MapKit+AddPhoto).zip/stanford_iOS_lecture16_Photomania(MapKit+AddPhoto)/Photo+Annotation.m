//
//  Photo+Annotation.m
//  Photomania_shijie
//
//  Created by SHIJIE on 16/7/23.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "Photo+Annotation.h"

@implementation Photo (Annotation)

- (CLLocationCoordinate2D)coordinate
{
    CLLocationCoordinate2D coordinate;
    coordinate.latitude = [self.latitude doubleValue];
    coordinate.longitude = [self.longitude doubleValue];
    return coordinate;
}

@end
