//
//  ViewController.m
//  CardMatchingGame
//
//  Created by SHIJIE on 16/6/26.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"
#import "PlayingCardDeck.h"
#import "CardMatchingGame.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *scoreLabel;
@property (nonatomic) int flipCount;
@property (nonatomic, strong) Deck *deck;
@property (nonatomic, retain) CardMatchingGame *game;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;
@end

@implementation ViewController


- (CardMatchingGame *)game
{
    if (!_game) {
        _game = [[CardMatchingGame alloc] initWithCardCount:[self.cardButtons count] usingDeck:[self createDeck]];
    }
    
    return _game;
}


- (Deck *)createDeck
{
    return [[PlayingCardDeck alloc] init];
}

/**
 *  tap action
 *
 *  @param sender button which is tapped
 */
- (IBAction)touchCardButton:(UIButton *)sender {
    
    //1. find the index of the button which is tapped on the screen
    NSInteger cardIndex = [self.cardButtons indexOfObject:sender];
    
    //2. find the corresponding data in the model
    [self.game chooseCardAtIndex: cardIndex];
    
    //3. updateUI
    [self updateUI];
    
}

/**
 *  update UI
 */
- (void)updateUI
{
    //1. update all the cards on the screen
    for (UIButton *cardButton in self.cardButtons) {
        
        //1.1 find a card on the screen
        NSInteger cardIndex = [self.cardButtons indexOfObject:cardButton];
        
        //1.2 find the data in the model
        Card *card  = [self.game cardAtIndex:cardIndex];
        
        //1.3 update the card by data
        [cardButton setTitle:[self titleForCard:card] forState:UIControlStateNormal];
        [cardButton setBackgroundImage: [self backgroundImageForCard:card] forState:UIControlStateNormal];
         cardButton.enabled = !card.isMatched;
        
        
    }
    
    //2. update score
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %ld", (long)self.game.score];
}

- (NSString *)titleForCard: (Card *)card
{
    return card.isChosen? card.contents:@"";
}

- (UIImage *)backgroundImageForCard: (Card *)card
{
    return [UIImage imageNamed:card.isChosen? @"cardFront.jpg":@"CardBack.png"];
}

@end
