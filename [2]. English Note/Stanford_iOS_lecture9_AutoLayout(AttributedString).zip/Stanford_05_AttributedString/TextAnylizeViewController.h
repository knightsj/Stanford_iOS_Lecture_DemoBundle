//
//  TextAnylizeViewController.h
//  Stanford_05_AttributedString
//
//  Created by SHIJIE on 16/7/2.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"

@interface TextAnylizeViewController : UIViewController

@property (nonatomic, retain) NSAttributedString *textToAnalyze;

@end
