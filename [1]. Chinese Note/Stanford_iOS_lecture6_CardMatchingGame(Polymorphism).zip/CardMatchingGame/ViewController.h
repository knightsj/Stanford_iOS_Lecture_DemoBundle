//
//  ViewController.h
//  CardMatchingGame
//
//  Created by SHIJIE on 16/6/26.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Deck.h"

@interface ViewController : UIViewController

/**
 *  abstract metod, for subclasses
 *
 *  @return 纸牌堆
 */
- (Deck *)createDeck;

@end

