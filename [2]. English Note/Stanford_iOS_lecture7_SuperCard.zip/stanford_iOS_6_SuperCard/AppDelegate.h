//
//  AppDelegate.h
//  stanford_iOS_6_SuperCard
//
//  Created by SHIJIE on 16/7/4.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

