//
//  CardMatchingGame.h
//  stanford_lecture2_card
//
//  Created by SHIJIE on 16/6/25.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Deck.h"

@interface CardMatchingGame : NSObject

@property (nonatomic, readonly) NSInteger score;//我只提供分数

- (instancetype)initWithCardCount:(NSUInteger)count usingDeck:(Deck *)deck;     //初始化
- (void)chooseCardAtIndex:(NSUInteger)index;                                    //选牌
- (Card*)cardAtIndex:(NSUInteger)index;                                         //

@end
