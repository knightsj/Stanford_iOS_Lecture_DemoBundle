//
//  ViewController.m
//  stanford_lecture2_card
//
//  Created by SHIJIE on 16/6/19.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "ViewController.h"
#import "PlayingCardDeck.h"
#import "CardMatchingGame.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *flipsLabel;
@property (nonatomic) int flipCount;
@property (nonatomic, strong) Deck *deck;
@property (nonatomic, retain) CardMatchingGame *game;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;

@end

@implementation ViewController

- (CardMatchingGame *)game
{
    if (!_game) {
        _game = [[CardMatchingGame alloc] initWithCardCount:0 usingDeck:[self createDeck]];
    }
    
    return _game;
}

- (Deck *)deck
{
    if (!_deck) {
        _deck = [self createDeck];
    }
    
    return _deck;
}

- (Deck *)createDeck
{
    return [[PlayingCardDeck alloc] init];
}

- (void)setFlipCount:(int)flipCount
{
    _flipCount = flipCount;
    
    //在setter方法完成后，设置标签的显示数字
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d", self.flipCount];
}


- (IBAction)touchCardButton:(UIButton *)sender {
    
    //先判断牌面：如果按钮的title有字，则为正面
    if ([sender.currentTitle length]) {
        
        //背面的UI效果
        
        //设置背景图片为背面的图片
        [sender setBackgroundImage:[UIImage imageNamed:@"cardBack"] forState:UIControlStateNormal];
        
        //设置按钮title为空，因为要翻到背面
        [sender setTitle:@"" forState:UIControlStateNormal];
        
        //翻拍次数记录。同时存在setter和getter方法。首先getter方法取到当前的翻拍次数，然后用setter方法让翻拍次数+1
        self.flipCount++;
        
        //更新Label显示的数字
        [self updateFlipsLabel];
        
    }else{
        
        Card *card = [self.deck drawRandomCard];
        
        if (card) {
            //正面的UI效果
            //设置背景图片为空
            [sender setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
            
            //设置背景颜色为白色
            [sender setBackgroundColor:[UIColor whiteColor]];
            
            //设置按钮title为牌的花色
            [sender setTitle:card.contents forState:UIControlStateNormal];
            
            //翻拍次数记录。同时存在setter和getter方法。首先getter方法取到当前的翻拍次数，然后用setter方法让翻拍次数+1
            self.flipCount++;
            
            //更新Label显示的数字
            [self updateFlipsLabel];
        }
        
    }
    
    
}

/**
 *  单独提取出更新Label显示的数字的方法
 */
- (void)updateFlipsLabel
{
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d", self.flipCount];
}

@end
