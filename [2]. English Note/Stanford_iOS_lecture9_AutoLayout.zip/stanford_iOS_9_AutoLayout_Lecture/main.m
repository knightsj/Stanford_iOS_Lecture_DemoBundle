//
//  main.m
//  stanford_iOS_9_AutoLayout_Lecture
//
//  Created by Shijie Sun on 16/7/7.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
