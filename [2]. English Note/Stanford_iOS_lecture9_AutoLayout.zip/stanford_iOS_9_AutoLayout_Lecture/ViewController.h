//
//  ViewController.h
//  stanford_iOS_9_AutoLayout_Lecture
//
//  Created by Shijie Sun on 16/7/7.
//  Copyright © 2016年 Shijie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

